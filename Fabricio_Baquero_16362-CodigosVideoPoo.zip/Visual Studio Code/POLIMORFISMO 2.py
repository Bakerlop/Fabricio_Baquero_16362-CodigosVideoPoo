def recorrer(elemento):
    for item in elemento:
        print(f"El elemento actual es: {item}")
        
lista1 = [1,2,3,4,5,6]
lista2 = ["HOLA","COMO","ESTAS?"]

recorrer(lista1)
recorrer(lista2)
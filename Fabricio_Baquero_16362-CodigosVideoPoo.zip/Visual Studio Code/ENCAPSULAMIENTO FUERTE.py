class Clase:
    def __init__(self):
        self.__atributo_privado = "Valor"
    def _hablar(self):
        print("Hola estoy hablando con usted")
objeto2 = Clase()
print(objeto2._hablar())
class Animal():
    def sonido(self):
        pass
class Gato ():
    def sonido (self):
        return "Miau"
    
class Perro ():
    def sonido(self):
        return "guau"

def hacer_sonido(animal):
    print(animal.sonido())    
    
gato = Gato()
Perro= Perro()

hacer_sonido(gato)

print("Como hace el gato?", gato.sonido())
    
from abc import ABC, abstractclassmethod
class Persona(ABC):

    @abstractclassmethod
    def __init__(self, nombre, edad, sexo, actividad):
        self.nombre = nombre
        self.edad = edad
        self.sexo = sexo
        self.actividad = actividad 
        
    @abstractclassmethod
    def hacer_actividad(self):
        pass
    
    def presentarse(self):
        print(f"Que tal mi nombre es {self.nombre} y tengo {self.edad} años de edad, soy de sexo {self.sexo}")

class Estudiante(Persona):
    def __init__ (self, nombre, edad, sexo, actividad):
        super().__init__(nombre, edad, sexo, actividad)
        
    def hacer_actividad(self):
        print(f"Estoy estudiando: {self.actividad}")
        

class Trabajador(Persona):
    def __init__ (self, nombre, edad, sexo, actividad):
        super().__init__(nombre, edad, sexo, actividad)
        
    def hacer_actividad(self):
        print(f"Soy {self.actividad}")
        
Fercho = Estudiante("Fabricio", "30", "masculino", "TICS")
Bakerlop = Trabajador("Fernando", "30", "masculino", "futuro ingeniero")

Fercho.presentarse()
Fercho.hacer_actividad()
Bakerlop.presentarse()
Bakerlop.hacer_actividad()

class Animal: 
    def saltar(self):
        print("salta")
    
    
class Mamifero(Animal):
    def criar(self):
        print("cria")
        
class Herbivoro(Animal): 
    def correr (self):
        print("corre")
        
class Zebra(Mamifero, Herbivoro):
    pass

zebra2 = Zebra()

zebra2.saltar()
zebra2.criar()
zebra2.correr()

    
    
    
    
         
class MiClase:
    def __init__(self):
        self._atributo_privado = "valor"
    def _hablar(self):
        print("Hola con quién tengo el gusto?")
objeto = MiClase()
print(objeto._atributo_privado)      
print(objeto._hablar())

class Persona: 
    def __init__(self, nombre, edad):
        self.nombre = nombre
        self.edad = edad
        
    def mostrar_datos(self):
        print(f"El nombre de la persona es: {self.nombre}")
        print(f"La edad de la persona es: {self.edad}")     
        
        
class Estudiante(Persona):
    def __init__(self, nombre, edad, semestre):
        super().__init__( nombre, edad)
        self.semestre = semestre
        
    def mostrar_semestre(self):
        print(f"El semestre del estudiante es: {self.semestre} semestre")
        
estudiante = Estudiante("Fabricio", "30 años", "Segundo")
estudiante.mostrar_datos()
estudiante.mostrar_semestre()
 
    
         
    
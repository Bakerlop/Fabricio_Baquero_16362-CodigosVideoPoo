class Personaje: 
    def __init__(self, nombre, edad):
        self.__nombre = nombre
        self.__edad = edad
      
    def get_nombre(self):
        return self.__nombre
   
    def set_nombre(self, new_nombre):
        self.__nombre = new_nombre

Bakerlop = Personaje("Fernanda", 1)

nombre = Bakerlop.get_nombre()
print(nombre)

caracter = input("Ingrese el nombre del Personaje: ")

Bakerlop.set_nombre(caracter)

nombre = Bakerlop.get_nombre()
print("El nombre de tu personaje es ", nombre)

        
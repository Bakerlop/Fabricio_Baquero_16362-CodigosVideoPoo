class Estudiante:
    def __init__(self,nombre,edad,semestre):
        self.nombre = nombre
        self.edad = edad
        self.semestre = semestre


Fabricio = Estudiante("Fabricio",30,2)


print(Fabricio.nombre)
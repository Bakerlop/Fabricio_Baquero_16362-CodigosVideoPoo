class Persona:
    def __init__(self, nombre, edad):
        self.nombre = nombre
        self.edad = edad
        
    def __str__(self):
        return f"Persona(nombre={self.nombre}, edad ={self.edad})"
    
    def __repr__(self):
        return f'Persona("{self.nombre}", {self.edad})'
    
    def __add__(self,otro):
        nuevo_valor= self.edad + otro.edad
        return Persona(self.nombre+otro.nombre,nuevo_valor)
    
Fabricio = Persona ("Fernando","30")
print(Fabricio)

lista = (1,2,3,4,5)
print(lista)

repre = repr(Fabricio)
resultado = eval(repre)
print(resultado.edad)
print(resultado.nombre)

Vane = Persona("Vanessa","29")
Javier = Persona("Javier","20")
nueva_individuo = Fabricio + Javier + Vane
print(nueva_individuo.nombre)
print(nueva_individuo.edad)


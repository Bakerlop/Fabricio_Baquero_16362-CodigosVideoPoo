class Persona: 
     def __init__(self, nombre, edad, nacionalidad):
         self.nombre = nombre
         self.edad= edad
         self.nacionalidad = nacionalidad
         
     def hablar(self):
        print(f"Buenas noches {self.nombre} y estoy conversando mucho")
         
class Empleado(Persona): 
    def __init__ (self, nombre, edad, nacionalidad, trabajo, salario): 
        super().__init__(nombre, edad, nacionalidad)
        self.trabajo = trabajo
        self.salario = salario

Fabricio = Empleado("Fabricio", "30", "Ecuatoriano", "Ingeniero", "2300 dolares")
Fabricio.hablar()

class Estudiante(Persona): 
    def __init__(self, nombre, edad, nacionalidad, universidad, carrera):
        super().__init__(nombre, edad, nacionalidad)
        self.universidad = universidad
        self.carrera = carrera
        
Fernando = Estudiante("Fernando", "30", "Ecuatoriano", "ESPE", "TICS")
print("El estudiante", Fernando.nombre, "tiene", Fernando.edad, "años, estudia en la", Fernando.universidad, "en la carrera", Fernando.carrera)
Fernando.hablar()
